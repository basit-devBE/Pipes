export default function Loader() {
    return (
        <span className="loading loading-spinner text-primary"></span>
    );
}